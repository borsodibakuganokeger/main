function display() {
    if(document.getElementById('c1c').checked) {
        document.getElementById("disp").innerHTML
            = document.getElementById("c1c").value
            + "";
    }
    else if(document.getElementById('c2c').checked) {
        document.getElementById("disp").innerHTML
            = document.getElementById("c2c").value
            + "";
    }
    else if(document.getElementById('c3c').checked) {
        document.getElementById("disp").innerHTML
            = document.getElementById("c3c").value
            + "";
    }
    else if(document.getElementById('c4c').checked) {
        document.getElementById("disp").innerHTML
            = document.getElementById("c4c").value
            + "";
    }
    else if(document.getElementById('c5c').checked) {
        document.getElementById("disp").innerHTML
            = document.getElementById("c5c").value
            + "";
    }
    else if(document.getElementById('c6c').checked) {
        document.getElementById("disp").innerHTML
            = document.getElementById("c6c").value
            + "";
    }
    else {
        document.getElementById("disp").innerHTML
            = "nincs kijelölve semmi";
    }
}

function display1() {
    if(document.getElementById('c1cc').checked) {
        document.getElementById("dispc").innerHTML
            = document.getElementById("c1cc").value
            + "";
    }
    else if(document.getElementById('c2cc').checked) {
        document.getElementById("dispc").innerHTML
            = document.getElementById("c2cc").value
            + "";
    }
    else if(document.getElementById('c3cc').checked) {
        document.getElementById("dispc").innerHTML
            = document.getElementById("c3cc").value
            + "";
    }
    else if(document.getElementById('c4cc').checked) {
        document.getElementById("dispc").innerHTML
            = document.getElementById("c4cc").value
            + "";
    }
    else if(document.getElementById('c5cc').checked) {
        document.getElementById("dispc").innerHTML
            = document.getElementById("c5cc").value
            + "";
    }
    else if(document.getElementById('c6cc').checked) {
        document.getElementById("dispc").innerHTML
            = document.getElementById("c6cc").value
            + "";
    }
    else {
        document.getElementById("dispc").innerHTML
            = "nincs kijelölve semmi";
    }
}

function display2() {
    if(document.getElementById('c1ccc').checked) {
        document.getElementById("dispcc").innerHTML
            = document.getElementById("c1ccc").value
            + "";
    }
    else if(document.getElementById('c2ccc').checked) {
        document.getElementById("dispcc").innerHTML
            = document.getElementById("c2ccc").value
            + "";
    }
    else if(document.getElementById('c3ccc').checked) {
        document.getElementById("dispcc").innerHTML
            = document.getElementById("c3ccc").value
            + "";
    }
    else if(document.getElementById('c4ccc').checked) {
        document.getElementById("dispcc").innerHTML
            = document.getElementById("c4ccc").value
            + "";
    }
    else if(document.getElementById('c5ccc').checked) {
        document.getElementById("dispcc").innerHTML
            = document.getElementById("c5ccc").value
            + "";
    }
    else if(document.getElementById('c6ccc').checked) {
        document.getElementById("dispcc").innerHTML
            = document.getElementById("c6ccc").value
            + "";
    }
    else {
        document.getElementById("dispcc").innerHTML
            = "nincs kijelölve semmi";
    }
}
